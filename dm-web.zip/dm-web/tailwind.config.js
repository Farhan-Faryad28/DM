/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src*.{html,js}"],  
    theme: {
      extend: {
        keyframes: {
          typing: {
            '0%': { width: '0' },
            '50%': { width: '8ch' }, // Adjust width to fit the longest word
            '100%': { width: '0' }, // Hide the word after typing
          },
          blink: {
            '0%, 100%': { borderColor: 'transparent' },
            '50%': { borderColor: 'currentColor' },
          },
        },
        animation: {
          typing: 'typing 4s steps(8, end) infinite, blink 0.7s step-end infinite',
        },
      },
    },
    plugins: [],
  };
  
  


document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll(".horizontal-scroll-wrapper > .slide");
  const controls = document.querySelectorAll(".control");
  const arrows = {
    left: document.querySelector(".arrow.left"),
    right: document.querySelector(".arrow.right"),
  };
  const horizontalScrollWrapper = document.querySelector(".horizontal-scroll-wrapper");

  let currentSlide = 0;
  let isScrolling = false;

  function updateArrowStates() {
    arrows.left.classList.toggle("disabled", currentSlide === 0);
    arrows.right.classList.toggle("disabled", currentSlide === slides.length - 1);
  }

  function updateControls() {
    controls.forEach((control, idx) => {
      control.classList.toggle("active", idx === currentSlide);
    });
  }

  function updateTextContent(index) {
    slides.forEach((slide, idx) => {
      const textContent = slide.querySelector(".text-content");
      if (textContent) {
        if (idx === index) {
          textContent.classList.remove("hidden"); // Show the correct text
          textContent.style.opacity = "1";
          textContent.style.transform = "translateY(0px)";
        } else {
          textContent.classList.add("hidden"); // Hide other text contents
          textContent.style.opacity = "0";
          textContent.style.transform = "translateY(10px)";
        }
      }
    });
  }

  function setActiveSlide(index) {
    if (index < 0 || index >= slides.length) return;

    currentSlide = index;
    slides[index].scrollIntoView({
      behavior: "smooth",
      block: "center",
      inline: "center",
    });

    updateControls();
    updateArrowStates();
    updateTextContent(index);

    setTimeout(() => {
      isScrolling = false;
    }, 600);
  }

  function detectCurrentSlide() {
    let closestSlideIndex = 0;
    let closestDistance = Infinity;

    slides.forEach((slide, index) => {
      const slideRect = slide.getBoundingClientRect();
      const wrapperRect = horizontalScrollWrapper.getBoundingClientRect();
      const distance = Math.abs(slideRect.left - wrapperRect.left);

      if (distance < closestDistance) {
        closestDistance = distance;
        closestSlideIndex = index;
      }
    });

    if (currentSlide !== closestSlideIndex) {
      currentSlide = closestSlideIndex;
      updateControls();
      updateArrowStates();
      updateTextContent(currentSlide);
    }
  }

  controls.forEach((control, index) => {
    control.addEventListener("click", () => {
      if (!isScrolling) {
        isScrolling = true;
        setActiveSlide(index);
      }
    });
  });

  arrows.left.addEventListener("click", () => {
    if (!isScrolling && currentSlide > 0) {
      isScrolling = true;
      setActiveSlide(currentSlide - 1);
    }
  });

  arrows.right.addEventListener("click", () => {
    if (!isScrolling && currentSlide < slides.length - 1) {
      isScrolling = true;
      setActiveSlide(currentSlide + 1);
    }
  });

  horizontalScrollWrapper.addEventListener(
    "wheel",
    (e) => {
      if (isScrolling) return;

      e.preventDefault();
      const deltaY = Math.sign(e.deltaY);

      if (deltaY > 0 && currentSlide < slides.length - 1) {
        isScrolling = true;
        setActiveSlide(currentSlide + 1);
      } else if (deltaY < 0 && currentSlide > 0) {
        isScrolling = true;
        setActiveSlide(currentSlide - 1);
      }
    },
    { passive: false }
  );

  horizontalScrollWrapper.addEventListener("scroll", () => {
    if (!isScrolling) {
      detectCurrentSlide();
    }
  });

  horizontalScrollWrapper.addEventListener("wheel", (e) => {
    e.preventDefault();
    e.stopPropagation();
  });

  // Initialize UI state on page load
  updateArrowStates();
  updateControls();
  updateTextContent(currentSlide);
});
